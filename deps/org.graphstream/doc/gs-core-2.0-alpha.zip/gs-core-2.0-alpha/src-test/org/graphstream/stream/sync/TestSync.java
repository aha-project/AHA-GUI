/*
 * This file is part of GraphStream <http://graphstream-project.org>.
 * 
 * GraphStream is a library whose purpose is to handle static or dynamic
 * graph, create them from scratch, file or any source and display them.
 * 
 * This program is free software distributed under the terms of two licenses, the
 * CeCILL-C license that fits European law, and the GNU Lesser General Public
 * License. You can  use, modify and/ or redistribute the software under the terms
 * of the CeCILL-C license as circulated by CEA, CNRS and INRIA at the following
 * URL <http://www.cecill.info> or under the terms of the GNU LGPL as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL-C and LGPL licenses and that you accept their terms.
 */

/**
 * @since 2009-12-07
 * 
 * @author Guilhelm Savin <guilhelm.savin@graphstream-project.org>
 */
package org.graphstream.stream.sync;

import org.graphstream.stream.sync.SinkTime;
import org.graphstream.stream.sync.SourceTime;
import org.junit.Test;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class TestSync {
	/**
	 * Used to access to disableSync.
	 */
	class TestSinkTime extends SinkTime {
		public boolean isSynchEnable() {
			return !disableSync;
		}
	}

	@Test
	public void testSync() {
		TestSinkTime tst = new TestSinkTime();
		SourceTime st = new SourceTime("test");

		if (tst.isSynchEnable()) {
			System.err.printf("sync is enable%n");

			assertTrue(tst.isNewEvent(st.getSourceId(), st.newEvent()));
			assertTrue(tst.isNewEvent(st.getSourceId(), st.newEvent()));
			assertTrue(tst.isNewEvent(st.getSourceId(), st.newEvent()));

			long timeId = st.newEvent();

			assertTrue(tst.isNewEvent(st.getSourceId(), timeId));
			assertFalse(tst.isNewEvent(st.getSourceId(), timeId));
		} else {
			System.err.printf("sync is disable%n");

			assertTrue(tst.isNewEvent(st.getSourceId(), st.newEvent()));
			assertTrue(tst.isNewEvent(st.getSourceId(), st.newEvent()));
			assertTrue(tst.isNewEvent(st.getSourceId(), st.newEvent()));

			long timeId = st.newEvent();

			assertTrue(tst.isNewEvent(st.getSourceId(), timeId));
			assertTrue(tst.isNewEvent(st.getSourceId(), timeId));
		}
	}
}
